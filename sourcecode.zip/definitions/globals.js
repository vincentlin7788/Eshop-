// Reads custom settings
$WORKFLOW('Settings', 'load');